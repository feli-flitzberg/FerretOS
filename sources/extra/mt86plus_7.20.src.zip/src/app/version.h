#define MT_VERSION "7.20"
#define GIT_HASH "unknown"
